package mundo;

public class ChivasRumberas 
{
	//------------------------------------------------------------------------------------
	// Atributos
	//------------------------------------------------------------------------------------
	private String nombre;         
	private int    capacidad;             
	private int    cantidadSillas;           
	private int    horasAlquiladas;         
	private double precioHora;               
	
	//------------------------------------------------------------------------------------
	// constructor 
	//---------------------------------------------
	
	public ChivasRumberas ( String pNombre, int pCapacidad, int pCantidadSillas, int pHorasAlquiladas, double pPrecioHora)
	{
		nombre = pNombre;
		capacidad = pCapacidad;
		cantidadSillas = pCantidadSillas;
		horasAlquiladas = pHorasAlquiladas;
		precioHora = pPrecioHora; 
	}
	//---------------------------------------------
	// Metodos
	//---------------------------------------------
	
	
	
	
	
	
	
	
	//------------------------------------------------------------------------------------
	
}
